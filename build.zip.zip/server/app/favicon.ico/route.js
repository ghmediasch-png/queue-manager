var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__8721ba20._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_353150a5.js")
R.m(17951)
module.exports=R.m(17951).exports
